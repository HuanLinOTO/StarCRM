import { eventHandler, getQuery } from 'h3';
import { u as useDB } from './useDB.mjs';
import 'minato';
import 'path';

function isSameDay(ts1, ts2) {
  const date1 = new Date(ts1);
  const date2 = new Date(ts2);
  return date1.getFullYear() === date2.getFullYear() && date1.getMonth() === date2.getMonth() && date1.getDate() === date2.getDate();
}

const get_statistics = eventHandler(async (event) => {
  const db = await useDB();
  var params = getQuery(event);
  if (params.today)
    params.today = true;
  if (params.date)
    params.date = Number(params.date);
  if (params.oid)
    params.oid = Number(params.oid);
  if (params.data2)
    params.data2 = Boolean(params.data2);
  const data = {
    creation: await db.get("statistics.creation", {}),
    sign: await db.get("statistics.sign", {}),
    contribution: {
      creation: void 0,
      sign: void 0
    }
  };
  const queryDate = params.today ? Date.now() : params.date;
  if (queryDate !== void 0) {
    data.creation = data.creation.filter((item) => isSameDay(item.date.getTime(), queryDate));
    data.sign = data.sign.filter((item) => isSameDay(item.date.getTime(), queryDate));
  }
  data.creation = data.creation.map((item) => {
    item.date = item.date.getTime();
    return item;
  }).filter((item) => !params.data2 || item.operator == params.oid);
  data.sign = data.sign.map((item) => {
    item.date = item.date.getTime();
    return item;
  }).filter((item) => !params.data2 || item.operator == params.oid);
  if (params.oid) {
    data.contribution.creation = data.creation.filter((item) => item.operator === params.oid).length;
    data.contribution.sign = data.sign.filter((item) => item.operator === params.oid).length;
  }
  return {
    code: 0,
    data
  };
});

export { get_statistics as default };
//# sourceMappingURL=get_statistics.mjs.map
