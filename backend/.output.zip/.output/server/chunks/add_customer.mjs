import { eventHandler, getQuery } from 'h3';
import { u as useDB } from './useDB.mjs';
import { g as getUser } from './getUser.mjs';
import 'minato';
import 'path';

const addCustomer = async (options) => {
  const db = await useDB();
  if ((await db.get("pool", { name: options.name })).length !== 0)
    return false;
  return await db.create("pool", {
    name: options.name,
    contact: options.contact,
    owner: options.owner,
    status: options.status,
    learnFrom: options.learnFrom,
    lastOperateTime: options.lastOperateTime
  });
};

const creation = async (params) => {
  const db = await useDB();
  const { id, date, operator, cid } = params;
  return await db.create("statistics.creation", { date, operator, cid });
};

const add_customer = eventHandler(async (event) => {
  const params = getQuery(event);
  if (!process.env.IGNORE_PREMISIION) {
    if (!params.name || !params.contact || !params.owner || !params.status || !params.learnFrom || !params.token)
      return { code: -1, msg: "\u7F3A\u5C11\u53C2\u6570" };
    const Owner = await getUser(params.token);
    if (!Owner.found)
      return { code: -2, msg: "token \u5F02\u5E38" };
    params.owner = Owner.role == "admin" ? params.owner : Owner.id;
  }
  const res = await addCustomer({
    name: params.name,
    contact: params.contact,
    owner: params.owner,
    status: params.status,
    learnFrom: params.learnFrom,
    lastOperateTime: /* @__PURE__ */ new Date()
  });
  if (res) {
    await creation({
      date: /* @__PURE__ */ new Date(),
      operator: params.owner,
      cid: res.id
    });
    return { code: 0, msg: "\u6DFB\u52A0\u6210\u529F" };
  } else {
    return { code: -2, msg: "\u91CD\u590D\u6DFB\u52A0" };
  }
});

export { add_customer as default };
//# sourceMappingURL=add_customer.mjs.map
