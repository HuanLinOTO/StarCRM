import { eventHandler, getQuery } from 'h3';
import { g as getUser } from './getUser.mjs';
import { v as verifyAdminByToken } from './verifyAdmin.mjs';
import './useDB.mjs';
import 'minato';
import 'path';

const get_user = eventHandler(async (event) => {
  const params = getQuery(event);
  if (!params.token)
    return { code: -1, msg: "\u7F3A\u5C11 token \u53C2\u6570" };
  if (params.token != "all" && !(await getUser(params.token)).found)
    return { code: -1, msg: "token \u65E0\u6548" };
  if (params.token == "all" && !params.admin_token)
    return { code: -1, msg: "\u7F3A\u5C11\u7BA1\u7406\u5458 token" };
  if (params.token == "all" && !await verifyAdminByToken(params.admin_token))
    return { code: -1, msg: "\u7BA1\u7406\u5458 token \u65E0\u6548" };
  return await getUser(params.token);
});

export { get_user as default };
//# sourceMappingURL=get_user.mjs.map
