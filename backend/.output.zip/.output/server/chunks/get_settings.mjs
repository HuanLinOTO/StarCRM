import { eventHandler } from 'h3';
import { g as getSettings } from './getSettings.mjs';
import 'fs-extra';

const get_settings = eventHandler(async (event) => {
  return await getSettings();
});

export { get_settings as default };
//# sourceMappingURL=get_settings.mjs.map
