import { u as useDB } from './useDB.mjs';
import { r as randstr } from './randstr.mjs';
import { g as getUser } from './getUser.mjs';

const add = async (name, password, role) => {
  const db = await useDB();
  if ((await db.get("users", { name })).length == 0)
    return db.create("users", { name, password, role });
  else
    return false;
};

const verify = async (name, password) => {
  const db = await useDB();
  const user = await db.get("users", { name, password });
  if (user.length === 0) {
    return { code: -2, msg: "\u7528\u6237\u540D\u6216\u5BC6\u7801\u9519\u8BEF" };
  } else {
    const token = randstr(32);
    await db.set("users", { id: user[0].id }, { token });
    console.log(`User ${user[0].name} logged in. Token: ${token}`);
    user[0].token = token;
    return { code: 0, msg: "\u767B\u9646\u6210\u529F", token, user: user[0] };
  }
};

const user = {
  verify,
  addUser: add,
  getUser
};

export { user as u };
//# sourceMappingURL=index.mjs.map
