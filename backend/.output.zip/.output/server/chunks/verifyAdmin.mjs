import { g as getUser } from './getUser.mjs';

async function verifyAdminByToken(token) {
  return (await getUser(token)).role == "admin";
}

export { verifyAdminByToken as v };
//# sourceMappingURL=verifyAdmin.mjs.map
