import { eventHandler, getQuery } from 'h3';
import { u as useDB } from './useDB.mjs';
import 'minato';
import 'path';

const editCustomer = async (params) => {
  const db = await useDB();
  let data = structuredClone(params);
  delete data.id;
  data.lastOperateTime = /* @__PURE__ */ new Date();
  return await db.set("pool", { id: params.id }, data);
};

const sign = async (params) => {
  const db = await useDB();
  const { id, date, operator, cid } = params;
  return await db.create("statistics.sign", { date, operator, cid });
};

const edit_customer = eventHandler(async (event) => {
  const params = getQuery(event);
  if (!params.name || !params.contact || !params.owner || !params.status || !params.learnFrom || !params.lastOperateTime)
    return { code: -1, msg: "\u7F3A\u5C11\u53C2\u6570" };
  if (params.status === "Signed")
    sign({
      operator: params.owner,
      cid: params.id,
      date: /* @__PURE__ */ new Date()
    });
  await editCustomer(params);
  return { code: 0, msg: "\u64CD\u4F5C\u6210\u529F" };
});

export { edit_customer as default };
//# sourceMappingURL=edit_customer.mjs.map
