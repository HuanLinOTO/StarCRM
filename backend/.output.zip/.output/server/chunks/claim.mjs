import { eventHandler, getQuery } from 'h3';
import { u as useDB } from './useDB.mjs';
import { g as getUser } from './getUser.mjs';
import 'minato';
import 'path';

const claim$1 = async (params) => {
  const db = await useDB();
  const { token, cid } = params;
  const user = await getUser(token);
  if (!user.found)
    return { code: -1, msg: "\u7528\u6237\u4E0D\u5B58\u5728\u6216\u8005token\u8FC7\u671F" };
  const { id } = user;
  db.set("pool", { id: cid }, { owner: id });
  return { code: 0, msg: "\u8BA4\u9886\u5BA2\u6237\u6210\u529F" };
};

const claim = eventHandler(async (event) => {
  const params = getQuery(event);
  if (!params.token || !params.cid)
    return { code: -1, msg: "\u7F3A\u5C11\u53C2\u6570" };
  return claim$1(params);
});

export { claim as default };
//# sourceMappingURL=claim.mjs.map
