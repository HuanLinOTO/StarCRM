import { eventHandler, getQuery } from 'h3';
import { u as useDB } from './useDB.mjs';
import 'minato';
import 'path';

const editUser = async (params) => {
  const db = await useDB();
  let data = structuredClone(params);
  delete data.id;
  db.set("users", { id: params.id }, data);
  return { code: 0, msg: "\u4FEE\u6539\u6210\u529F" };
};

const edit_user = eventHandler(async (event) => {
  const params = getQuery(event);
  if (!params.id || !params.name || !params.password || !params.token || !params.role)
    return { code: -1, msg: "\u7F3A\u5C11\u53C2\u6570" };
  return editUser(params);
});

export { edit_user as default };
//# sourceMappingURL=edit_user.mjs.map
