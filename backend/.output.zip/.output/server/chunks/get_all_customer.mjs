import { eventHandler, getQuery } from 'h3';
import { u as useDB } from './useDB.mjs';
import { v as verifyAdminByToken } from './verifyAdmin.mjs';
import 'minato';
import 'path';
import './getUser.mjs';

const get_all_customer = eventHandler(async (event) => {
  const params = getQuery(event);
  if (!await verifyAdminByToken(params.token))
    return { code: -1, msg: "\u7BA1\u7406\u5458 token \u65E0\u6548" };
  const db = await useDB();
  return await db.get("pool", {});
});

export { get_all_customer as default };
//# sourceMappingURL=get_all_customer.mjs.map
