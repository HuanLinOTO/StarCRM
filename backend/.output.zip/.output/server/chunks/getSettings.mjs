import fs from 'fs-extra';

const checkFile = async () => {
  const isExists = await fs.pathExists("./settings.json");
  if (!isExists)
    await fs.outputJson("./settings.json", {
      dailyCreation: 50
    });
};

const getSettings = async () => {
  await checkFile();
  return await fs.readJson("./settings.json");
};

export { getSettings as g };
//# sourceMappingURL=getSettings.mjs.map
