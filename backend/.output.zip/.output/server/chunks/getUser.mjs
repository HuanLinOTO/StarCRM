import { u as useDB } from './useDB.mjs';

const getUser = async (token) => {
  const db = await useDB();
  const users = (token == "all" || token == "name" ? await db.get("users", {}) : await db.get("users", { token })).map((item) => {
    if (token == "name") {
      delete item.token;
      delete item.password;
      delete item.dailyCreation;
      delete item.role;
    }
    return item;
  });
  if (users.length == 0)
    return { found: false };
  return token == "all" || token == "name" ? { users, found: true } : { ...users[0], found: true };
};

export { getUser as g };
//# sourceMappingURL=getUser.mjs.map
