import { eventHandler, getQuery } from 'h3';
import { u as user } from './index.mjs';
import { u as useStorage } from './nitro/node-server.mjs';
import './useDB.mjs';
import 'minato';
import 'path';
import './randstr.mjs';
import './getUser.mjs';
import 'node-fetch-native/polyfill';
import 'node:http';
import 'node:https';
import 'destr';
import 'ofetch';
import 'unenv/runtime/fetch/index';
import 'hookable';
import 'scule';
import 'klona';
import 'defu';
import 'ohash';
import 'ufo';
import 'unstorage';
import 'radix3';
import 'node:fs';
import 'node:url';
import 'pathe';
import 'http-graceful-shutdown';

const login = eventHandler(async (event) => {
  const storage = useStorage();
  const params = getQuery(event);
  if (!params.name || !params.password || !params.captcha || !params.ctoken)
    return { code: -1, msg: "\u7F3A\u5C11\u53C2\u6570" };
  const captcha_token = await storage.getItem(`captcha.${params.ctoken}`);
  if (!captcha_token || params.captcha !== captcha_token)
    return { code: -1, msg: "\u9A8C\u8BC1\u7801\u9519\u8BEF" };
  return await user.verify(params.name, params.password);
});

export { login as default };
//# sourceMappingURL=login.mjs.map
