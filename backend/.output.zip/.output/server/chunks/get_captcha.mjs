import { eventHandler, getQuery } from 'h3';
import { r as randstr } from './randstr.mjs';
import { create, CaptchaConfigManager } from 'gimpy-captcha';
import { u as useStorage } from './nitro/node-server.mjs';
import 'node-fetch-native/polyfill';
import 'node:http';
import 'node:https';
import 'destr';
import 'ofetch';
import 'unenv/runtime/fetch/index';
import 'hookable';
import 'scule';
import 'klona';
import 'defu';
import 'ohash';
import 'ufo';
import 'unstorage';
import 'radix3';
import 'node:fs';
import 'node:url';
import 'pathe';
import 'http-graceful-shutdown';

const captchaConfig = CaptchaConfigManager.default({
  mode: "code",
  // or code
  // cryptoKey: Buffer.from("ezrvvv"),
  // signatureKey: Buffer.from("man0lett3"),
  noise: 20
});
let query_count = 0, stopCount = 0;
let clearQueryCountInterval = null;
let clearStopCountInterval = null;
const get_captcha = eventHandler(async (event) => {
  query_count++;
  if (!clearQueryCountInterval) {
    clearQueryCountInterval = setInterval(() => {
      query_count = 0;
    }, 60 * 1e3);
  }
  const storage = useStorage();
  if (query_count > 30) {
    event.res.statusCode = 429;
    storage.clear();
    stopCount++;
    if (stopCount > 3) {
      if (!clearStopCountInterval)
        setTimeout(() => {
          stopCount = 0;
          clearStopCountInterval = null;
        }, 5 * 1e3 * 60);
      return { code: 429, msg: "\u63A5\u53E3\u53D7\u5230\u4E25\u91CD\u653B\u51FB\uFF0C\u5C06\u957F\u65F6\u95F4\u5173\u95ED\u9A8C\u8BC1\u7801" };
    }
    return { code: 429, msg: "\u63A5\u53E3\u53D7\u5230\u653B\u51FB\uFF0C\u6682\u65F6\u5173\u95ED\u9A8C\u8BC1\u7801" };
  }
  getQuery(event);
  const token = randstr(32);
  const captcha = create(captchaConfig);
  await storage.setItem(`captcha.${token}`, JSON.parse(captcha.expr).captcha.code);
  setTimeout(() => {
    storage.removeItem(`captcha.${token}`);
  }, 60 * 60 * 100);
  return {
    img: captcha.captchaSvg,
    token
  };
});

export { get_captcha as default };
//# sourceMappingURL=get_captcha.mjs.map
