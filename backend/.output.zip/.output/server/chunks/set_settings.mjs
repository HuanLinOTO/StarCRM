import { eventHandler, getQuery } from 'h3';
import fs from 'fs-extra';
import { g as getSettings } from './getSettings.mjs';

const setSettings = async (params) => {
  const settings = await getSettings();
  settings[params.key] = params.value;
  fs.outputJson("./settings.json", settings);
  return { code: 0, msg: "\u4FEE\u6539\u6210\u529F" };
};

const set_settings = eventHandler(async (event) => {
  const params = getQuery(event);
  if (!params.key || !params.value)
    return { code: -1, msg: "\u7F3A\u5C11\u53C2\u6570" };
  return await setSettings(params);
});

export { set_settings as default };
//# sourceMappingURL=set_settings.mjs.map
