import { eventHandler, getQuery } from 'h3';
import { u as useDB } from './useDB.mjs';
import { g as getUser } from './getUser.mjs';
import 'minato';
import 'path';

const getPublic = async () => {
  const db = await useDB();
  return await db.get("pool", { owner: -1 });
};

const get_public = eventHandler(async (event) => {
  const params = getQuery(event);
  if (!params.token)
    return { code: -1, msg: "\u7F3A\u5C11\u53C2\u6570" };
  if (!(await getUser(params.token)).found)
    return { code: -1, msg: "token \u65E0\u6548" };
  return await getPublic();
});

export { get_public as default };
//# sourceMappingURL=get_public.mjs.map
