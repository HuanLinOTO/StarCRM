import { eventHandler, getQuery } from 'h3';
import { u as useDB } from './useDB.mjs';
import { g as getUser } from './getUser.mjs';
import 'minato';
import 'path';

const getPrivate = async (token) => {
  const db = await useDB();
  const user = await getUser(token);
  if (!user.found)
    return [];
  const data = await db.get("pool", { owner: user.id });
  const today = /* @__PURE__ */ new Date();
  const ninetyDaysAgo = new Date(today.getTime() - 90 * 24 * 60 * 60 * 1e3);
  const result = data.filter((item) => {
    const lastOperateTime = new Date(item.lastOperateTime);
    return lastOperateTime < ninetyDaysAgo;
  });
  result.forEach((item) => {
    item.owner = -1;
    const { id } = item;
    delete item.id;
    db.set("pool", { id }, item);
  });
  return data.filter((item) => {
    const lastOperateTime = new Date(item.lastOperateTime);
    return lastOperateTime >= ninetyDaysAgo;
  });
};

const get_private = eventHandler(async (event) => {
  const params = getQuery(event);
  if (!params.token)
    return { code: -1, msg: "\u7F3A\u5C11 token \u53C2\u6570" };
  return await getPrivate(params.token);
});

export { get_private as default };
//# sourceMappingURL=get_private.mjs.map
