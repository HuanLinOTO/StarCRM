import { eventHandler, getQuery } from 'h3';
import { u as user } from './index.mjs';
import { v as verifyAdminByToken } from './verifyAdmin.mjs';
import './useDB.mjs';
import 'minato';
import 'path';
import './randstr.mjs';
import './getUser.mjs';

const add_user = eventHandler(async (event) => {
  const params = getQuery(event);
  if (!process.env.IGNORE_PREMISIION) {
    if (!params.name || !params.password || !params.role || !params.token)
      return { code: -1, msg: "\u7F3A\u5C11\u53C2\u6570" };
    if (!await verifyAdminByToken(params.token))
      return { code: -2, msg: "\u6743\u9650\u4E0D\u8DB3" };
  }
  if (await user.addUser(params.name, params.password, params.role))
    return { code: 0, msg: "\u6DFB\u52A0\u6210\u529F" };
  else
    return { code: -1, msg: "\u6DFB\u52A0\u5931\u8D25\uFF0C\u91CD\u590D\u7528\u6237" };
});

export { add_user as default };
//# sourceMappingURL=add_user.mjs.map
